package com.dfp.persistence.dao;

public interface PasajeroDaoInterface {

}

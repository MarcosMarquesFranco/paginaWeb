package com.dfp.core.dto;

/**
 * Created by Marcos on 01/01/2019.
 */
public class DireccionDTO {

    private String calle="";

    private String numero="";

    private String puerta="";

    private String codigoPostal="";

    private String localidad="";

    private String provincia="";

    private String nacion="";
}

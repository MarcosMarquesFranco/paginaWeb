package com.dfp.core.dto;


public class PruebaDTO {
	
	String nombre = "";

}

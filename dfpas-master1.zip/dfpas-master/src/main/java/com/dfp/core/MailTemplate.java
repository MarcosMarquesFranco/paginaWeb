package com.dfp.core;

public class MailTemplate {

}
